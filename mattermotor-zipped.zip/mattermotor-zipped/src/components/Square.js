import React from "react";
import "../styles/style.css";
function Square({ value, onSquareClick }) {
  return (
    <div className='square' onClick={onSquareClick}>
      <h1>{value}</h1>
    </div>
  );
}
export default Square;
