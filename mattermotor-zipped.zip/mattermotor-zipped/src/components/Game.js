import { useState } from "react";
import Board from "./Board";
function Game() {
  let initialHistory = [Array(9).fill(null)];
  const [history, setHistory] = useState(initialHistory); // [[null,null,null,null,null,null,null,null,null]]
  const [currentMove, setCurrentMove] = useState(0); // 0
  let currentSquares = history[currentMove];
  const xIsNext = currentMove % 2 === 0;
  function handlePlay(nextSquares = []) {
    if (nextSquares.length === 0) {
      setHistory(() => [Array(9).fill(null)]);
      setCurrentMove(() => 0);
      return;
    }
    const nextHistory = [...history.slice(0, currentMove + 1), nextSquares];
    setHistory(nextHistory);
    setCurrentMove(nextHistory.length - 1);
  }
  return (
    <div class='game'>
      <Board xIsNext={xIsNext} squares={currentSquares} onPlay={handlePlay} />
    </div>
  );
}
export default Game;
